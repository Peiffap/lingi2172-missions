This folder contains all submitted files for group I’s second project.


Each of the exercises (web application, soccer, and trains) has its own subdirectory:

1. The first contains the updated conceptual diagrams, as well as a physical design schema, SQL queries to generate a database structure and the report explaining design choices.

2. The second contains an ER/Crow’s Foot diagram for the “soccer” database, as well as SQL queries to generate a database structure which respects 1NF.

3. The third contains a physical design schema for the “trains” database, as well as SQL queries to generate it.